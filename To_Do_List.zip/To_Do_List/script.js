const newTask = document.getElementById("input");
const addTask = document.getElementById("add-btn");
const taskList = document.getElementById("task-list");

// Event listener for adding task via button click
addTask.addEventListener("click", addToList);

// Event listener for adding task via Enter key
newTask.addEventListener("keyup", (e) => {
    if (e.key === "Enter") {
        addToList();
    }
});

function addToList() {
    let text = newTask.value.trim(); // Trim whitespace
    if (text === "") {
        alert("Please enter a valid task!");
        return;
    }

    // Create task list item
    const listItem = document.createElement("li");
    listItem.classList.add("task-item");

    // Create check button
    const checkbox = document.createElement("button");
    checkbox.classList.add("btn-check");
    checkbox.innerHTML = `<i class="fa-solid fa-check"></i>`;

    // Create task text span
    const span = document.createElement("span");
    span.classList.add("text");
    span.textContent = text;

    // Create delete button
    const closeButton = document.createElement("button");
    closeButton.classList.add("btn-close");
    closeButton.innerHTML = `<i class="fa-solid fa-xmark"></i>`;

    // Append elements to list item
    listItem.appendChild(checkbox);
    listItem.appendChild(span);
    listItem.appendChild(closeButton);

    // Append list item to task list
    taskList.appendChild(listItem);

    // Clear input field after adding task
    newTask.value = "";

    // Task completion toggle
    checkbox.addEventListener("click", () => {
        listItem.classList.toggle("completed");
    });

    // Task deletion
    closeButton.addEventListener("click", () => {
        listItem.remove();
    });
}
